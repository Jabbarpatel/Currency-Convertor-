#include<iostream>
using namespace std;
void start()
{
    cout<<"---------------------------------------------------"<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"-----------WELCOME TO CURRENCY CONVERTOR-----------"<<endl;
    cout<<"-----------CHOOSE THE OPTIONS FROM BELOW-----------"<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"1.CONVERT RUPEES TO DOLLAR(USD)"<<endl;
    cout<<"2.CONVERT DOLLAR TO RUPEES"<<endl;
    cout<<"3.CONVERT RUPEES TO POUND"<<endl;
    cout<<"4.CONVERT POUND TO RUPEES"<<endl;
    cout<<"5.CONVERT RUPEES TO KUWAITI DINAR(KWD)"<<endl;
    cout<<"6.CONVERT KUWAITI DINAR TO RUPEES"<<endl;
    cout<<"7.CONVERT RUPEES TO EURO(EUR)"<<endl;
    cout<<"8.CONVERT EURO TO RUPEES"<<endl;
    cout<<"9.CONVERT RUPESS TO CHINESE YUAN"<<endl;
    cout<<"10.CONVERT CHINESE YUAN TO RUPEES"<<endl;
    cout<<"11.EXIT"<<endl;
}
int rupeestodollar(int currency)
{
    int currency1=currency/82.06;
    cout<<currency<<" RUPEES = "<<currency1<<" DOLLARS"<<endl;
}
int dollartorupees(int currency)
{
    int currency2=currency*82.06;
    cout<<currency<<" DOLLARS = "<<currency2<<" RUPEES"<<endl;
}
int rupeestopound(int currency)
{
    int currency3=currency/99.10;
    cout<<currency<<" RUPEES = "<<currency3<<" POUNDS"<<endl;
}
int poundtorupees(int currency)
{
    int currency4=currency*99.10;
    cout<<currency<<" POUNDS = "<<currency4<<" RUPEES"<<endl;
}
int rupeestokwd(int currency)
{
    int currency5=currency/266.96;
    cout<<currency<<" RUPEES = "<<currency5<<" KWD"<<endl;
}
int kwdtorupees(int currency)
{
    int currency6=currency*266.96;
    cout<<currency<<" KWD = "<<currency6<<" RUPEES"<<endl;
}
int rupeestoeuro(int currency)
{
    int currency7=currency/87.56;
    cout<<currency<<" RUPEES = "<<currency7<<" EURO"<<endl;
}
int eurotorupees(int currency)
{
    int currency8=currency*87.56;
    cout<<currency<<" EURO = "<<currency8<<" RUPEES"<<endl;
}
int rupeestoyuan(int currency)
{
    int currency9=currency/11.84;
    cout<<currency<<" RUPEES = "<<currency9<<" YUAN"<<endl;
}
int yuantorupees(int currency)
{
    int currency10=currency*11.84;
    cout<<currency<<" YAUN = "<<currency10<<" RUPEES"<<endl;
}
void condition(char ch)
{
    if(ch=='y'||ch=='Y')
            start();
        else
           exit(0);
}
int main()
{
    cout<<"---------------------------------------------------"<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"-----------WELCOME TO CURRENCY CONVERTOR-----------"<<endl;
    cout<<"-----------CHOOSE THE OPTIONS FROM BELOW-----------"<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"1.CONVERT RUPEES TO DOLLAR(USD)"<<endl;
    cout<<"2.CONVERT DOLLAR TO RUPEES"<<endl;
    cout<<"3.CONVERT RUPEES TO POUND"<<endl;
    cout<<"4.CONVERT POUND TO RUPEES"<<endl;
    cout<<"5.CONVERT RUPEES TO KUWAITI DINAR(KWD)"<<endl;
    cout<<"6.CONVERT KUWAITI DINAR TO RUPEES"<<endl;
    cout<<"7.CONVERT RUPEES TO EURO(EUR)"<<endl;
    cout<<"8.CONVERT EURO TO RUPEES"<<endl;
    cout<<"9.CONVERT RUPESS TO CHINESE YUAN"<<endl;
    cout<<"10.CONVERT CHINESE YUAN TO RUPEES"<<endl;
    cout<<"11.PRESS FOR EXIT"<<endl;
    int choice=0;
    char ch;
    long double currency;
    while(choice!=11)
    {
    cin>>choice;
    switch(choice)
    {
        case 1:
        cout<<"ENTER THE RUPEES"<<endl;
        cin>>currency;
        cout<<rupeestodollar(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 2:
        cout<<"ENTER THE DOLLAR"<<endl;
        cin>>currency;
        cout<<dollartorupees(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 3:
        cout<<"ENTER THE RUPEES"<<endl;
        cin>>currency;
        cout<<rupeestopound(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 4:
        cout<<"ENTER THE POUND"<<endl;
        cin>>currency;
        cout<<poundtorupees(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 5:
        cout<<"ENTER THE RUPEES"<<endl;
        cin>>currency;
        cout<<rupeestokwd(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 6:
        cout<<"ENTER THE KUWAIT DINAR"<<endl;
        cin>>currency;
        cout<<kwdtorupees(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 7:
        cout<<"ENTER THE RUPEES"<<endl;
        cin>>currency;
        cout<<rupeestoeuro(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 8:
        cout<<"ENTER THE EURO"<<endl;
        cin>>currency;
        cout<<eurotorupees(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 9:
        cout<<"ENTER THE RUPEES"<<endl;
        cin>>currency;
        cout<<rupeestoyuan(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 10:
        cout<<"ENTER THE YUHN"<<endl;
        cin>>currency;
        cout<<yuantorupees(currency);
        cout<<"\nTO REUSE ENTER THE y or n";
        cin>>ch;
        condition(ch);
        break;
        case 11:
            exit(0);
            break;
        default:
            cout<<"Please enter valid input "<<endl;
            break;
    }
    }
    return 0;
}
